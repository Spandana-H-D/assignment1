package ProblemStatement1_3;
import java.util.Scanner;



public class TestBook 
{
	public static void main (String[] args) {
        Scanner Sc=new Scanner(System.in);
        
        System.out.println("Enter the Book name:");
        String bookname=Sc.nextLine();
        
        System.out.println("Enter the price:");
        int price=Sc.nextInt();
        Sc.nextLine();
        
        
        Book obj=new Book();
        obj.setBookName(bookname);
        obj.setBookPrice(price);
        System.out.println("Book Details");
        System.out.println("Book Name :"+obj.getBookName());
        System.out.println("Book Price :"+obj.getBookPrice());
       
    }	
	
}

