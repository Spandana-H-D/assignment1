package ProblemStatement6_1;
import java.util.* ;
public class p_6_1{
public static void main(String[] args) {
	ArrayList<String> alist=new ArrayList<String>();//Creating arraylist  
    alist.add("Rani");//Adding object in arraylist  
    alist.add("Raja");  
    alist.add("Anu");  
    alist.add("Ani");
    alist.add("kumar");
    alist.add("teja");
    System.out.println(alist);
    
    if (alist.contains("Rani"))
        System.out.println("Rani exists in the ArrayList");

    else
        System.out.println("Rani does not exist in the ArrayList");

    if (alist.contains("spandu"))
        System.out.println("spandu exists in the ArrayList");

    else
        System.out.println("spandu does not exist in the ArrayList");
    
}
}


