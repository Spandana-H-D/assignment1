package ProblemStatement7_3;


public class Product {
	
	private Integer Product_Id;
	private String Product_Name;
	
	

	public Integer getProduct_Id() {
		return Product_Id;
	}


	public void setProduct_Id(Integer Product_Id) {
		this.Product_Id = Product_Id;
	}


	public String getProdct_Name() {
		return Product_Name;
	}


	public void setProdct_Name(String prodct_Name, String Product_Name) {
		this.Product_Name = Product_Name;
	}


	public Product(Integer product_Id, String prodct_Name, String Product_Name, Integer Product_Id) {
		super();
		this.Product_Id = Product_Id;
		this.Product_Name = Product_Name;
	}
}
