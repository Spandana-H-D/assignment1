package ProblemStatement3_1;


public abstract class instrument
{
public abstract void Play();
}



